import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-admin-product-media',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-white shadow rounded-lg p-6">
      <h3 class="text-sm font-bold text-gray-900 uppercase tracking-wider mb-4 border-b pb-2">Galería Principal</h3>

      <div class="grid grid-cols-2 gap-3 mb-4">
         <div *ngFor="let img of images" class="relative group aspect-square bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
           <img [src]="img.url" class="w-full h-full object-cover">
           <div *ngIf="img.primary" class="absolute top-1 left-1 bg-green-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow">MAIN</div>

           <div class="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity gap-2">
              <button (click)="onSetPrimary.emit(img.id)" title="Principal" class="text-white hover:text-green-300">★</button>
              <button (click)="onDelete.emit(img.id)" title="Borrar" class="text-white hover:text-red-300">🗑</button>
           </div>
         </div>
      </div>

      <div class="space-y-2 pt-2 border-t">
         <input [(ngModel)]="newUrl" class="block w-full text-xs border-gray-300 rounded p-2 border" placeholder="https://...">
         <button (click)="upload()" [disabled]="!newUrl" class="w-full py-1.5 border border-dashed text-gray-600 text-xs font-medium rounded hover:bg-gray-50">
           + Subir Imagen
         </button>
      </div>
    </div>
  `
})
export class AdminProductMediaComponent {
  @Input() images: any[] = [];
  @Output() onUpload = new EventEmitter<string>();
  @Output() onDelete = new EventEmitter<number>();
  @Output() onSetPrimary = new EventEmitter<number>();

  newUrl = '';

  upload() {
    if(this.newUrl) {
      this.onUpload.emit(this.newUrl);
      this.newUrl = '';
    }
  }
}
