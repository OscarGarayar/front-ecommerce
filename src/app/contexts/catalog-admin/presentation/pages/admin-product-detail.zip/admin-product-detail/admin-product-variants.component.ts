import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpCatalogAdminRepository } from '../../../data/repositories/http-catalog-admin.repository';

@Component({
  selector: 'app-admin-product-variants',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
        <h3 class="text-lg font-medium text-gray-900">Variantes e Inventario</h3>
      </div>

      <div class="p-6 bg-blue-50 border-b border-blue-100">
        <h4 class="text-xs font-bold text-blue-700 uppercase tracking-wider mb-3">Nueva Variante</h4>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 items-start">

          <div class="relative">
            <label class="text-xs font-semibold text-gray-600 block mb-1">SKU *</label>
            <input
              [(ngModel)]="newSku"
              (input)="checkSku()"
              list="existingSkus"
              [class.border-red-500]="skuError"
              [class.focus:ring-red-500]="skuError"
              class="w-full text-sm border-gray-300 rounded p-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Ej. POL-BLA-S">

            <datalist id="existingSkus">
              <option *ngFor="let v of variants" [value]="v.sku">Ya existe</option>
            </datalist>

            <p *ngIf="skuError" class="text-xs text-red-600 mt-1 absolute -bottom-5 left-0">
              ¡Este SKU ya existe!
            </p>
          </div>

          <div>
            <label class="text-xs font-semibold text-gray-600 block mb-1">Atributo *</label>
            <select [(ngModel)]="newKey" class="w-full text-sm border-gray-300 rounded p-2 bg-white">
              <option value="Size">Size (Talla)</option>
              <option value="Color">Color</option>
            </select>
          </div>

          <div>
            <label class="text-xs font-semibold text-gray-600 block mb-1">Valor *</label>
            <input
              [(ngModel)]="newVal"
              [list]="newKey === 'Size' ? 'sizeOptions' : 'colorOptions'"
              class="w-full text-sm border-gray-300 rounded p-2"
              [placeholder]="newKey === 'Size' ? 'Ej. M, 42...' : 'Ej. Rojo, #FF0000...'">

            <datalist id="sizeOptions">
              <option value="XS">Extra Small</option>
              <option value="S">Small</option>
              <option value="M">Medium</option>
              <option value="L">Large</option>
              <option value="XL">Extra Large</option>
              <option value="XXL">2X Large</option>
            </datalist>

            <datalist id="colorOptions">
              <option value="Negro">Básico</option>
              <option value="Blanco">Básico</option>
              <option value="Rojo">Primario</option>
              <option value="Azul">Primario</option>
              <option value="Verde">Primario</option>
              <option value="Multicolor">Estampado</option>
            </datalist>
          </div>

          <div>
            <label class="text-xs font-semibold text-gray-600 block mb-1">Precio Base</label>
            <input type="number" [(ngModel)]="newPrice" class="w-full text-sm border-gray-300 rounded p-2" min="0">
          </div>
        </div>

        <button (click)="createVariant()"
                [disabled]="!newSku || !newVal || skuError"
                class="mt-6 w-full bg-blue-600 text-white text-sm font-bold py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors">
          <span *ngIf="skuError">Corrige el SKU para continuar</span>
          <span *ngIf="!skuError">+ Crear Variante</span>
        </button>
      </div>

      <ul class="divide-y divide-gray-200" *ngIf="variants.length > 0; else empty">
        <li *ngFor="let v of variants" class="p-6 hover:bg-gray-50 transition-colors">

          <div class="flex justify-between items-start mb-4">
            <div>
              <div class="flex items-center gap-2">
                <span class="text-lg font-bold text-gray-900">{{ v.sku }}</span>
                <span class="text-xs bg-gray-200 px-2 py-0.5 rounded text-gray-700 font-mono">ID: {{v.id}}</span>
              </div>
              <div class="mt-1 flex gap-2">
                <span *ngFor="let item of v.attributes | keyvalue"
                      class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
                  {{ item.key }}: {{ item.value }}
                </span>
              </div>
            </div>

            <button (click)="onDelete.emit(v.id)" class="text-red-500 hover:text-red-700 text-sm underline">
              Eliminar
            </button>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 bg-white border border-gray-200 rounded-lg p-4">

            <div>
              <h5 class="text-xs font-bold text-gray-500 uppercase mb-2">Precio & Estado</h5>
              <div *ngIf="pricingData[v.id]; else loadPriceBtn">
                <div class="flex items-center justify-between mb-2">
                  <span class="text-xl font-bold text-gray-900">S/ {{ pricingData[v.id].basePrice }}</span>
                  <span class="text-xs px-2 py-1 rounded font-bold"
                        [ngClass]="pricingData[v.id].active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'">
                    {{ pricingData[v.id].active ? 'ACTIVO' : 'INACTIVO' }}
                  </span>
                </div>
                <div class="flex gap-2">
                  <button *ngIf="!pricingData[v.id].active" (click)="activatePrice(v.id)" class="flex-1 py-1 text-xs bg-green-600 text-white rounded hover:bg-green-700">Activar</button>
                  <button *ngIf="pricingData[v.id].active" (click)="deactivatePrice(v.id)" class="flex-1 py-1 text-xs bg-gray-200 text-gray-600 rounded hover:bg-gray-300">Desactivar</button>
                </div>
              </div>
              <ng-template #loadPriceBtn>
                <button (click)="loadVariantDetails(v.id)" class="text-xs text-indigo-600 underline">Ver precio</button>
              </ng-template>
            </div>

            <div class="border-l pl-4 border-gray-100">
              <h5 class="text-xs font-bold text-gray-500 uppercase mb-2">Inventario</h5>
              <div *ngIf="inventoryData[v.id]; else loadStockBtn">
                <div class="flex items-center gap-2 mb-2">
                   <span class="text-2xl font-bold" [ngClass]="inventoryData[v.id].quantityOnHand > 0 ? 'text-gray-900' : 'text-red-600'">
                     {{ inventoryData[v.id].quantityOnHand }}
                   </span>
                  <span class="text-xs text-gray-500">unid.</span>
                </div>
                <div class="flex gap-2">
                  <input type="number" [(ngModel)]="stockInput[v.id]" class="w-16 text-xs border rounded p-1" placeholder="Cant.">
                  <button (click)="addStock(v.id)" class="px-2 py-1 bg-indigo-600 text-white text-xs rounded hover:bg-indigo-700">+</button>
                  <button (click)="decreaseStock(v.id)" class="px-2 py-1 bg-red-100 text-red-600 text-xs rounded hover:bg-red-200">-</button>
                </div>
              </div>
              <ng-template #loadStockBtn>
                <button (click)="loadVariantDetails(v.id)" class="text-xs text-indigo-600 underline">Ver stock</button>
              </ng-template>
            </div>
          </div>

          <div class="mt-3 pt-3 border-t border-gray-100">
            <label class="text-xs font-bold text-gray-500">Imágenes Específicas</label>
            <div class="flex gap-2 mt-2">
              <input [(ngModel)]="imgInputs[v.id]" class="flex-1 text-xs border rounded p-1" placeholder="URL Imagen">
              <button (click)="addImage(v.id)" class="text-xs border px-2 rounded hover:bg-gray-50">Subir</button>
            </div>
            <div class="flex gap-2 mt-2 overflow-x-auto">
              <img *ngFor="let img of v.images" [src]="img.url" class="w-10 h-10 object-cover rounded border">
            </div>
          </div>
        </li>
      </ul>
      <ng-template #empty><div class="p-6 text-center text-gray-400">Sin variantes.</div></ng-template>
    </div>
  `
})
export class AdminProductVariantsComponent {
  @Input() variants: any[] = [];
  @Input() productId!: number;

  @Output() onCreate = new EventEmitter<any>();
  @Output() onDelete = new EventEmitter<number>();
  @Output() onRefresh = new EventEmitter<void>();

  // Nuevos Defaults
  newSku = '';
  newKey = 'Size'; // Default a Talla
  newVal = '';
  newPrice = 0;

  skuError = false;

  // Cache
  imgInputs: Record<number, string> = {};
  stockInput: Record<number, number> = {};
  pricingData: Record<number, any> = {};
  inventoryData: Record<number, any> = {};

  constructor(private repo: HttpCatalogAdminRepository) {}

  // Validar SKU en tiempo real
  checkSku() {
    if (!this.newSku) {
      this.skuError = false;
      return;
    }
    // Verifica si existe en la lista local de variantes
    const exists = this.variants.some(v => v.sku.toUpperCase() === this.newSku.trim().toUpperCase());
    this.skuError = exists;
  }

  createVariant() {
    this.checkSku();
    if (this.skuError || !this.newSku || !this.newVal) return;

    this.onCreate.emit({
      sku: this.newSku,
      attributes: { [this.newKey]: this.newVal },
      price: this.newPrice
    });

    // Resetear formulario
    this.newSku = '';
    this.newVal = '';
    // newKey y newPrice se mantienen para facilitar carga masiva
  }

  // --- MÉTODOS EXISTENTES (Logic de Stock/Precio) ---
  loadVariantDetails(variantId: number) {
    this.repo.getPrice(variantId).subscribe({ next: (res) => this.pricingData[variantId] = res });
    this.repo.getInventory(variantId).subscribe({ next: (res) => this.inventoryData[variantId] = res });
  }

  activatePrice(variantId: number) {
    this.repo.activatePrice(variantId).subscribe(() => this.loadVariantDetails(variantId));
  }
  deactivatePrice(variantId: number) {
    this.repo.deactivatePrice(variantId).subscribe(() => this.loadVariantDetails(variantId));
  }

  addStock(variantId: number) {
    const qty = this.stockInput[variantId];
    if (!qty || qty <= 0) return;
    this.repo.increaseStock(variantId, qty).subscribe(() => {
      this.stockInput[variantId] = 0;
      this.loadVariantDetails(variantId);
    });
  }
  decreaseStock(variantId: number) {
    const qty = this.stockInput[variantId];
    if (!qty || qty <= 0) return;
    this.repo.decreaseStock(variantId, qty).subscribe(() => {
      this.stockInput[variantId] = 0;
      this.loadVariantDetails(variantId);
    });
  }

  addImage(variantId: number) {
    const url = this.imgInputs[variantId];
    if(!url) return;
    this.repo.addVariantImage(this.productId, variantId, { url, type: 'GALLERY' }).subscribe(() => {
      this.imgInputs[variantId] = '';
      this.onRefresh.emit();
    });
  }
}
